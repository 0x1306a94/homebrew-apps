#!/bin/sh

#  setup.sh
#  ytoo-clashx-rule-merge
#
#  Created by king on 2019/12/19.
#  Copyright © 2019 K&K. All rights reserved.

if [[ ! -f "$HOME/.clashx-rule-merge/conf.yaml" ]];
then
	echo "init conf ..."
	mkdir -p $HOME/.clashx-rule-merge
	echo "Rule:" > $HOME/.clashx-rule-merge/conf.yaml
fi